package com.fse.restaurantapi.query;

import java.util.List;

import javax.validation.constraints.NotBlank;

public class MenuQueryEvent {

	@NotBlank(message = "Menu name is required")
	private String name;

	private List<RestaurantQueryEvent> restaurantQueryEvent;

	public MenuQueryEvent() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<RestaurantQueryEvent> getRestaurantQueryEvent() {
		return restaurantQueryEvent;
	}

	public void setRestaurantQueryEvent(List<RestaurantQueryEvent> restaurantQueryEvent) {
		this.restaurantQueryEvent = restaurantQueryEvent;
	}
}
