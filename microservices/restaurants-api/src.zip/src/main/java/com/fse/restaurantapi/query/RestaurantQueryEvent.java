package com.fse.restaurantapi.query;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class RestaurantQueryEvent {
	@NotBlank(message = "Restaurant name is required")
	private String name;

	@NotBlank(message = "Restaurant Address is required")
	private String address;

	@Min(value = 1, message = "Restaurant ratings must be at least 1")
	@Max(value = 10, message = "Restaurant ratings must be at most 10")
	private double ratings;

	@Valid
	@NotNull(message = "Menu is required")
	@Size(min = 1, message = "Menu must have at least one item")
	private List<MenuQueryEvent> menu;

	public RestaurantQueryEvent() {
		// Default constructor
	}

	public RestaurantQueryEvent(String name, String address, double ratings, List<MenuQueryEvent> menu) {
		this.name = name;
		this.address = address;
		this.ratings = ratings;
		this.menu = menu;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getRatings() {
		return ratings;
	}

	public void setRatings(double ratings) {
		this.ratings = ratings;
	}

	public List<MenuQueryEvent> getMenu() {
		return menu;
	}

	public void setMenu(List<MenuQueryEvent> menu) {
		this.menu = menu;
	}

	public static class RestaurantBuilder {
		private String name;
		private String address;
		private double ratings;
		private List<MenuQueryEvent> menu;
		
		public RestaurantBuilder name(String name) {
			this.name = name;
			return this;
		}

		public RestaurantBuilder address(String address) {
			this.address = address;
			return this;
		}

		public RestaurantBuilder ratings(double ratings) {
			this.ratings = ratings;
			return this;
		}

		public RestaurantBuilder menu(List<MenuQueryEvent> menu) {
			this.menu = menu;
			return this;
		}

		
		public RestaurantQueryEvent build() {
			RestaurantQueryEvent restaurant = new RestaurantQueryEvent();
			restaurant.setName(this.name);
			restaurant.setAddress(this.address);
			restaurant.setRatings(this.ratings);
			restaurant.setMenu(this.menu);
			return restaurant;
		}
	}

}
